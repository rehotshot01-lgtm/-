package com.pravda.offlineai

import com.pravda.offlineai.engine.CandidateMetrics
import com.pravda.offlineai.engine.VerificationGate
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VerificationGateTest {
    private val baseline = CandidateMetrics(.98, .80, .99, 1.0, .01)
    @Test fun rejectsRegression() {
        val candidate = baseline.copy(correctness = .90)
        assertFalse(VerificationGate.evaluate(candidate, baseline).accepted)
    }
    @Test fun acceptsCandidateThatMeetsStarterGate() {
        val candidate = baseline.copy(efficiency = .85)
        assertTrue(VerificationGate.evaluate(candidate, baseline).accepted)
    }
}
